Chris Charis Concept logo pack.
Full-colour logo: chris-charis-logo-original.png
"-light" versions are for dark backgrounds (charcoal lettering shown in white).
Vector (SVG) master files: available on request.
